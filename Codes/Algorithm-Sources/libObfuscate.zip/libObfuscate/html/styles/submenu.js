var submenu = '<table width="90%"><tr>'+
'<td><img src="./images/embeddedsw_little.gif" alt="embeddedsw_little.gif" width="100px" height="100px"></td>'+
'<td valign="middle"><h1 style="font-size:48px; font-variant:small-caps;"><b>EmbeddedSW.net</b></h1>'+
'<h3 style="font-variant:small-caps;">Security Technology - Cryptography &amp; Obfuscation - Consulting<br>'+
'SW&amp;HW Development - Industrial Machinery - Retrofitting<br>'+
'<b>> <i>Delivering Advanced &amp; Reliable Innovation</i> <</b></h3></td>'+
'<td><img src="./images/embeddedsw_logo_little.gif" alt="embeddedsw_logo_little.gif" width="60px" height="100px"></td>'+
'</tr></table>';

document.write(submenu);