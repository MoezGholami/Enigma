var global_sidebar = '<h4>&nbsp;</h4>'+
'<!-- GLOB -->'+
'<div style="height:100px;">'+
'<script id="_wauviz">'+
'var _wau = _wau || [];'+
'_wau.push(["map", "n2nm0gnw7zbb", "viz", "200", "100", "cart" , "star-yellow"]);'+
'(function() { var s=document.createElement("script");s.src="http://widgets.amung.us/map.js";'+
' s.async=true; document.getElementsByTagName("head")[0].appendChild(s); })();</script>'+
'</div>'+
'<!-- GLOB -->'+
'<h3>Worldwide Visitors</h3>'+
'<table><tr>'+
'<td valign="middle">'+
'<!-- FACEBOOK -->'+
'<a href="http://www.facebook.com/pages/EmbeddedSW/228431677213272"><img src="./images/facebook.jpg" alt="facebook.jpg"></a>'+
'<!-- END -->'+
'</td>'+
'<td valign="middle">'+
'<!-- SHINYSTAT -->'+
'<script type="text/javascript" src="http://codice.shinystat.com/cgi-bin/getcod.cgi?USER=puffv2"></script>'+
'<noscript>'+
'<a href="http://www.shinystat.com/it" target="_top">'+
'<img src="http://www.shinystat.com/cgi-bin/shinystat.cgi?USER=puffv2" alt="Contatore sito"></a>'+
'</noscript>'+
'<!-- END -->'+
'</td>'+
'</tr></table>'+
'<h4>&nbsp;</h4>';

document.write(global_sidebar);